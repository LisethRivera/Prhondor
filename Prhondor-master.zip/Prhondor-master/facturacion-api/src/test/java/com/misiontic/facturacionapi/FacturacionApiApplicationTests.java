package com.misiontic.facturacionapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacturacionApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
