package com.misiontic.facturacionapi.controllers;

public class MiController {

}
