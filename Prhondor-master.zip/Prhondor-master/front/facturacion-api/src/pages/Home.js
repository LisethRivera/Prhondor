import React from "react";
import Navbar from "../components/Navbar";

class Home extends React.Component{
    render() {
        return (
            <><div>
                <Navbar />
            </div><h1>BIENVENIDO</h1></>
        )
    }
}
export default Home