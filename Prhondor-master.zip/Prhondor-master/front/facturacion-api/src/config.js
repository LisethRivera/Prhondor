module.exports = {
    api: {
        baseURL: "http://localhost:8080"
    }
}